$(document).ready(function() {
  $('.poem-stanza').addClass('highlight');
});
